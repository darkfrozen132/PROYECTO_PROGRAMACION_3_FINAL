
package pe.edu.pucp.cbancaria.model;

public enum Estado_CB {
    ACTIVO,INACTIVO;
}
