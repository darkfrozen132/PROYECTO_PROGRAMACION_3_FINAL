/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.pucp.usuario.model;

/**
 *
 * @author rodri
 */
public enum Tipo_Usuario {
    CLIENTE,EMPRESA,PROVEEDOR,EMPLEADO;
}
