
package pe.edu.pucp.usuario.model;

public class Empesa extends Usuario{

}
