package pe.edu.pucp.dbmanager.config;

public enum Tipo_Operacion {
    INSERTAR, MODIFICAR, ELIMINAR, LISTAR, OBTENER_POR_ID
}
